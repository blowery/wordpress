using System;
using System.IO;
using System.Security.Cryptography;
using SH=CryptoSamples.StreamHelpers;

namespace CryptoSamples {
  /// <summary>
  /// Summary description for SignatureSample.
  /// </summary>
  public class SignatureSample : Sample {
    const string s_plaintext = "plaintext.txt";

    public override void Run() {
      using(RSA rsa = RSA.Create()) {
        VerifySignature(rsa, CreateSignature(rsa));
      }
    }

    private byte[] CreateSignature(AsymmetricAlgorithm alg) {
      AsymmetricSignatureFormatter format = 
        new RSAPKCS1SignatureFormatter(alg);
      format.SetHashAlgorithm("SHA1");
      byte[] sig = format.CreateSignature(GetHash(s_plaintext));
      PrintSig(s_plaintext, sig);
      return sig;
                                             
    }

    private void VerifySignature(AsymmetricAlgorithm alg, byte[] sig) {
      AsymmetricSignatureDeformatter format = 
        new RSAPKCS1SignatureDeformatter(alg);
      format.SetHashAlgorithm("SHA1");
      Console.WriteLine(
        "The signature of {0} is {1}", 
        s_plaintext,
        format.VerifySignature(GetHash(s_plaintext), sig) ? "valid" : "invalid");
    }

    private byte[] GetHash(string path) {
      using(Stream input = SH.GetReadOnlyFileStream(path))
      using(HashAlgorithm hashAlg = HashAlgorithm.Create("SHA1")) {
        return hashAlg.ComputeHash(input);
      }
    }

    private void PrintSig(string what, byte[] hash) {
      Console.WriteLine("Signature of {0}: {1}", what, Convert.ToBase64String(hash));
    }
  }
}
