using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace CryptoSamples
{
	public class KeyExchangeSample : Sample
	{
  
    const string s_secret = "too many secrets"; 
    const string s_publicKeyFile = "blowery.pubkey";

    public override void Run() {
      
      byte[] exchange;
      string pubKeyStr;

      using(RSA privKey = RSA.Create()) {
        // make public key
        pubKeyStr = privKey.ToXmlString(false); 
        Console.WriteLine("My public key is {0}", pubKeyStr);

        // load the public key
        RSA pubKey = RSA.Create();
        pubKey.FromXmlString(pubKeyStr);

        exchange = CreateKeyExchange(pubKey);
        CrackKeyExchange(privKey, exchange);
      }
    }

    private byte[] CreateKeyExchange(RSA rsa) {
      AsymmetricKeyExchangeFormatter format = new RSAPKCS1KeyExchangeFormatter(rsa);
      return format.CreateKeyExchange(CreateSecret());
    }

    private void CrackKeyExchange(RSA rsa, byte[] keyExchange) {
      AsymmetricKeyExchangeDeformatter format = new RSAPKCS1KeyExchangeDeformatter(rsa);
      byte[] secret = format.DecryptKeyExchange(keyExchange);
      Console.WriteLine("Ah ha! The secret is '{0}'", Encoding.ASCII.GetString(secret));
    }

    private byte[] CreateSecret() {
      Console.WriteLine("Shhhh! The secret is '{0}'", s_secret);
      return Encoding.ASCII.GetBytes(s_secret);
    }
  }
}
