using System;
using System.IO;
using System.Security.Cryptography;
using SH = CryptoSamples.StreamHelpers;

namespace CryptoSamples {
  /// <summary>
  /// A little sample of encrypting one file into another.
  /// </summary>
  class Base64EncryptionSample : Sample {

    const string s_plaintext = "plaintext.txt";
    const string s_ciphertext = "simple-ciphertext.bin";
    const string s_decrypted = "simple-plaintext-decrypted.txt";
    
    public override void Run() {
      using(SymmetricAlgorithm algo = SymmetricAlgorithm.Create("Rijndael")) {
        Encrypt(algo);
        Decrypt(algo);     
      }
    }

    private void Encrypt(SymmetricAlgorithm algo) {
      using(Stream cipherText = SH.GetWriteableFileStream(s_ciphertext))
      using(ICryptoTransform b64 = new ToBase64Transform())
      using(ICryptoTransform enc = algo.CreateEncryptor())
      using(CryptoStream toBase64 = SH.GetWriteCryptoStream(cipherText, b64))
      using(CryptoStream crypt = SH.GetWriteCryptoStream(toBase64, enc))
      using(Stream input = SH.GetReadOnlyFileStream(s_plaintext)) {
        SH.Pump(input, crypt);        
        crypt.Close(); // have to call, not called by Dispose
      }
    }

    private void Decrypt(SymmetricAlgorithm algo) {
      using(Stream cipherText = SH.GetReadOnlyFileStream(s_ciphertext))
      using(ICryptoTransform b64 = new FromBase64Transform())
      using(ICryptoTransform dec = algo.CreateDecryptor())
      using(CryptoStream frBase64 = SH.GetReadCryptoStream(cipherText, b64))
      using(CryptoStream decrypt = SH.GetReadCryptoStream(frBase64, dec))
      using(Stream output = SH.GetWriteableFileStream(s_decrypted)) {
        SH.Pump(decrypt, output);
        decrypt.Close(); // have to call, not called by Dispose
      }
    }
  }
}