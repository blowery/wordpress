using System;
using System.IO;
using System.Security.Cryptography;

namespace CryptoSamples
{
  /// <summary>
  /// Some helpers for stream work
  /// </summary>
  public class StreamHelpers {
    private StreamHelpers() { }

    public static void Pump(Stream input, Stream output) {
      byte[] buffer = new byte[1024];
      int count = 0;
      while((count = input.Read(buffer, 0, 1024)) != 0) {
        output.Write(buffer, 0, count);
      }
      output.Flush();
    }

    public static FileStream GetReadOnlyFileStream(string path) {
      return new FileStream(path, FileMode.Open, FileAccess.Read);
    }

    public static FileStream GetWriteableFileStream(string path) {
      return new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write);
    }

    public static CryptoStream GetWriteCryptoStream(Stream stream, ICryptoTransform transform) {
      return new CryptoStream(stream, transform, CryptoStreamMode.Write);
    }

    public static CryptoStream GetReadCryptoStream(Stream stream, ICryptoTransform transform) {
      return new CryptoStream(stream, transform, CryptoStreamMode.Read);
    }
  }
}
