using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using SH=CryptoSamples.StreamHelpers;

namespace CryptoSamples {

  /// <summary>
  /// Class that defines a sample
  /// </summary>
  public abstract class Sample {
    public abstract void Run();
  }

  /// <summary>
  /// Entry point for the console app
  /// </summary>
  class EntryPoint {
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main(string[] args) {
      ArrayList samples = new ArrayList();
      samples.Add(new SimpleEncryptionSample());
      samples.Add(new Base64EncryptionSample());
      samples.Add(new HashingSample());
      samples.Add(new SignatureSample());
      samples.Add(new KeyExchangeSample());


      foreach(Sample sample in samples) {
        Console.WriteLine("Running {0}... ", sample.ToString());
        sample.Run();
        Console.WriteLine("Done!");
        Console.WriteLine();
      }
    }
  }
}
