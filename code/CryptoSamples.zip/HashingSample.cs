using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using SH = CryptoSamples.StreamHelpers;

namespace CryptoSamples {
  /// <summary>
  /// A little sample of encrypting one file into another.
  /// </summary>
  class HashingSample : Sample {

    const string s_plaintext = "plaintext.txt";
    
    public override void Run() {
      HashStream();
      HashBytes();     
     
    }

    private void HashStream() {
      using(Stream input = SH.GetReadOnlyFileStream(s_plaintext))
      using(HashAlgorithm hashAlg = HashAlgorithm.Create("MD5")) {
        byte[] hash = hashAlg.ComputeHash(input);
        PrintHash(s_plaintext, hash);
      }
    }

    private void HashBytes() {
      string password = "my-password";
      using(HashAlgorithm hash = HashAlgorithm.Create("MD5")) {
        byte[] hashed = hash.ComputeHash(Encoding.ASCII.GetBytes(password));
        PrintHash(password, hashed);
      }
    }

    private void PrintHash(string what, byte[] hash) {
      Console.WriteLine("Hash of {0}: {1}", what, Convert.ToBase64String(hash));
    }
  }
}