using System;
using System.IO;

namespace OurFirstFilter
{
	/// <summary>
	/// A pass through filter.  It takes what was
	/// written and just passes it on through, with no modification.
	/// </summary>
	public class PassThroughFilter : HttpFilter
	{
    public PassThroughFilter(Stream baseStream) : base(baseStream) {}
		
    public override void Write(byte[] buffer, int offset, int count) {
      if(Closed) throw new ObjectDisposedException("PassThroughFilter");
      BaseStream.Write(buffer, offset, count);
      
    }
	}
}
