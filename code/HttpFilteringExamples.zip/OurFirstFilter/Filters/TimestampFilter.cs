using System;
using System.IO;

namespace OurFirstFilter
{
	/// <summary>
	/// This filter is a really bad idea.
	/// </summary>
	public class TimestampFilter : HttpFilter
	{
    bool firstWrite = true;

    public TimestampFilter(Stream baseStream) : base(baseStream) {}

    public override void Write(byte[] buffer, int offset, int count) {
      if(firstWrite) {
        byte[] timestamp = GetCommentTimeStamp();
        BaseStream.Write(timestamp, 0, timestamp.Length); 
        firstWrite = false;
      }
      BaseStream.Write(buffer, offset, count);
    }

    byte[] GetCommentTimeStamp() {
      string ts = string.Format("<!-- Generated @ {0:yyyyMMdd hhmmss} -->", DateTime.Now);
      return System.Text.Encoding.UTF8.GetBytes(ts);
    }

  }
}
