using System;
using System.Collections;
using System.Configuration;
using System.Xml.XPath;

namespace OurFirstFilter
{
  public class Catch22Config {

    public static ArrayList GetForbiddenWords() {
      ArrayList wordsFromConfig = (ArrayList)ConfigurationSettings.GetConfig("forbiddenWords");
      if(wordsFromConfig == null)
        return new ArrayList();
      return wordsFromConfig;
    }
  }

  /// <summary>
  /// Summary description for ForbiddenWordsSectionHandler.
  /// </summary>
  public class ForbiddenWordsSectionHandler : IConfigurationSectionHandler {	
    public ForbiddenWordsSectionHandler() {}

    public object Create(object parent, object configContext, System.Xml.XmlNode section) {
      XPathNavigator nav = section.CreateNavigator();
      XPathNodeIterator iter = nav.SelectChildren("word", "urn:WashingtonIrving");
      ArrayList words = new ArrayList(iter.Count);
      while(iter.MoveNext()) {
        words.Add(iter.Current.Value + " ");
      }
      return words;
    }
  }
}
