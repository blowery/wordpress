using System;
using System.Collections;
using System.IO;
using System.Text;

namespace OurFirstFilter {
  /// <summary>
  /// Summary description for Catch22Filter.
  /// </summary>
  public class Catch22Filter : HttpFilter {
    Encoding encoding;
    ArrayList words;
    byte[] startStrikeThrough;
    byte[] endStrikeThrough;
    public Catch22Filter(Stream baseStream, Encoding encoding) : base(baseStream) { 
      this.encoding = encoding;
      this.words = new ArrayList();
      ArrayList wordsFromConfig = Catch22Config.GetForbiddenWords();
      foreach(string word in wordsFromConfig) {
        words.Add(encoding.GetBytes(word));
      }
      startStrikeThrough = encoding.GetBytes("<s style='background:#000;color:#000'>");
      endStrikeThrough = encoding.GetBytes("</s>");
    }
    
    public override void Write(byte[] buffer, int offset, int count) {
      byte[] currentWord;
      bool wordFound = false;
      int wordLength = -1;
      int lastIndexWrote = offset;
      int i = 0;
      for(i=offset; i < count; ++i) {
        wordFound = false;
        for(int wordIndex = 0; wordIndex < words.Count; ++wordIndex) {
          currentWord = (byte[])words[wordIndex];
          if(WordMatches(buffer, i, currentWord)) {
            wordFound = true;
            wordLength = currentWord.Length;
            break;
          }
          else {
            wordFound = false;
          }
        }
        if(wordFound) {
          if(lastIndexWrote != i) {
            BaseStream.Write(buffer, lastIndexWrote, i - lastIndexWrote);
          }
          BaseStream.Write(startStrikeThrough, 0, startStrikeThrough.Length);
          BaseStream.Write(buffer, i, wordLength);
          BaseStream.Write(endStrikeThrough, 0, endStrikeThrough.Length);
          i += wordLength;
          lastIndexWrote = i;
          
        }
      }
      if(lastIndexWrote != count) {
        BaseStream.Write(buffer, lastIndexWrote, count - lastIndexWrote);
      }
    }

    private bool WordMatches(byte[] buffer, int offset, byte[] word) {
      for(int i = 0; i < word.Length; ++i) {
        if(buffer[i+offset] != word[i])
          return false;
      }
      return true;
    }

  }
}
