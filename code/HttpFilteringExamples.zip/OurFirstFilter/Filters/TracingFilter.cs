using System;
using System.IO;

namespace OurFirstFilter {
  /// <summary>
  /// A Filter that writes out the calls made to it to a TextStream
  /// </summary>
  public class TracingFilter : HttpFilter {

    public TracingFilter(Stream baseStream) : base(baseStream) {
      Log.Write(this, "Construction of new TracingFilter instance");
    }

    public override bool CanWrite {
      get {
        Log.Write(this, "CanWrite");
        return base.CanWrite;
      }
    }

    public override void Close() {
      Log.Write(this, "Close");
      base.Close ();
    }

    public override void Flush() {
      Log.Write(this, "Flush");
      base.Flush();
    }

    public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state) {
      Log.Write(this, "BeginWrite");
      return base.BeginWrite (buffer, offset, count, callback, state);
    }

    public override void EndWrite(IAsyncResult asyncResult) {
      Log.Write(this, "EndWrite");
      base.EndWrite (asyncResult);
    }



    public override void Write(byte[] buffer, int offset, int count) {
      Log.Write(this, "Write; buffer length={0}; offset={1}; count={2}", buffer.Length, offset, count);
      BaseStream.Write(buffer, offset, count);
    }

    public override void WriteByte(byte value) {
      Log.Write(this, "WriteByte; value={0:x2}", value);
      BaseStream.WriteByte(value);
    }

  }
}
