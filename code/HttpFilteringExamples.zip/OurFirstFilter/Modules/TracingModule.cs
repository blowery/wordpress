using System;
using System.IO;
using System.Web;

namespace OurFirstFilter {
  /// <summary>Our very first HttpModule that does some filtering</summary>
  public class TracingModule : IHttpModule {

    /// <summary>
    /// Implementation of IHttpModule.Init.
    /// Perform Filter initialization here.
    /// </summary>
    public void Init(HttpApplication app) {
      Log.Write(this, "Init");
      app.BeginRequest += new EventHandler(app_BeginRequest);
      app.AuthenticateRequest +=new EventHandler(app_AuthenticateRequest);
      app.AuthorizeRequest +=new EventHandler(app_AuthorizeRequest);
      app.Disposed += new EventHandler(app_Disposed);
      app.EndRequest += new EventHandler(app_EndRequest);
      app.Error += new EventHandler(app_Error);
      app.PostRequestHandlerExecute += new EventHandler(app_PostRequestHandlerExecute);
      app.PreRequestHandlerExecute += new EventHandler(app_PreRequestHandlerExecute);
      app.PreSendRequestContent += new EventHandler(app_PreSendRequestContent);
      app.PreSendRequestHeaders += new EventHandler(app_PreSendRequestHeaders);
      app.ReleaseRequestState += new EventHandler(app_ReleaseRequestState);
      app.ResolveRequestCache += new EventHandler(app_ResolveRequestCache);
      app.UpdateRequestCache += new EventHandler(app_UpdateRequestCache);
    }

    /// <summary>
    /// Implementation of IHttpModule.Dispose.
    /// Perform Filter cleanup here.
    /// </summary>
    public void Dispose() {
      Log.Write(this, "Dispose");
    }

    private void app_BeginRequest(object sender, EventArgs e) {
      Log.Write(this, "BeginRequest");
    }

    private void app_AuthenticateRequest(object sender, EventArgs e) {
      Log.Write(this, "AuthenticateRequest");
    }

    private void app_AuthorizeRequest(object sender, EventArgs e) {
      Log.Write(this, "AuthorizeRequest");
    }

    private void app_Disposed(object sender, EventArgs e) {
      Log.Write(this, "Disposed");
    }

    private void app_EndRequest(object sender, EventArgs e) {
      Log.Write(this, "EndRequest");
    }

    private void app_Error(object sender, EventArgs e) {
      Log.Write(this, "Error");
    }

    private void app_PostRequestHandlerExecute(object sender, EventArgs e) {
      Log.Write(this, "PostRequestHandlerExecute");
    }

    private void app_PreRequestHandlerExecute(object sender, EventArgs e) {
      Log.Write(this, "PreRequestHandlerExecute");
    }

    private void app_PreSendRequestContent(object sender, EventArgs e) {
      Log.Write(this, "PreSendRequestContent"); 
    }

    private void app_PreSendRequestHeaders(object sender, EventArgs e) {
      Log.Write(this, "PreSendRequestHeaders");
    }

    private void app_ReleaseRequestState(object sender, EventArgs e) {
      Log.Write(this, "ReleaseRequestState");
    }

    private void app_ResolveRequestCache(object sender, EventArgs e) {
      Log.Write(this, "ResolveRequestCache");
    }

    private void app_UpdateRequestCache(object sender, EventArgs e) {
      Log.Write(this, "UpdateRequestCache");
    }
  }
}
