using System;
using System.Web;

namespace OurFirstFilter {
  public class HtmlOnlyFilteringModule : IHttpModule {

    const string CONTEXT_KEY = "HttpOnlyFilteringModuleInstalled";

    public void Init(HttpApplication context) {
      context.ReleaseRequestState += new EventHandler(HandleOpportunityToInstall);
      // have to sink PreSendRequestHeaders too to handle calls to Flush
      // comment this next line out and hit Flusher.ashx to see it fail
      context.PreSendRequestHeaders += new EventHandler(HandleOpportunityToInstall);
    }

    public void Dispose() { }

    private void HandleOpportunityToInstall(object sender, EventArgs e) {
      Log.Write(this, "Handling opportunity to install");

      if(!HttpContext.Current.Items.Contains(CONTEXT_KEY)) {
      
        HttpResponse response = HttpContext.Current.Response;

        Log.Write(this, "Current ContentType is " + response.ContentType);
        if(response.ContentType == "text/html") {
          Log.Write(this, "Installing filter");
          response.Filter = new TimestampFilter(response.Filter);      
        }

        HttpContext.Current.Items.Add(CONTEXT_KEY, new object());
      }            
    }
  }
}
