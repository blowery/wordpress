using System;
using System.IO;
using System.Web;

namespace OurFirstFilter
{
	/// <summary>Our very first HttpModule that does some filtering</summary>
	public class FilteringModule : IHttpModule
	{
    /// <summary>
    /// Implementation of IHttpModule.Init.
    /// Perform Filter initialization here.
    /// </summary>
    public void Init(HttpApplication app) {
      Log.Write(this, "Init");
		  app.BeginRequest += new EventHandler(this.HandleBeginRequest);
    }

    /// <summary>
    /// Implementation of IHttpModule.Dispose.
    /// Perform Filter cleanup here.
    /// </summary>
    public void Dispose() {
      Log.Write(this, "Dispose");
    }

    /// <summary>
    /// This is an event sink for HttpApplication.BeginRequest.
    /// We install the filter here.
    /// </summary>
    private void HandleBeginRequest(object sender, EventArgs e) {
      Log.Write(this, "HandleBeginRequest");
      HttpApplication app = (HttpApplication)sender;
      app.Context.Response.Filter = new TracingFilter(app.Context.Response.Filter);
      //app.Context.Response.Filter = new Catch22Filter(app.Context.Response.Filter, app.Context.Response.Output.Encoding);
    }
  }
}
