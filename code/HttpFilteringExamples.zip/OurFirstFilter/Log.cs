using System;
using System.IO;
using System.Web;

namespace OurFirstFilter
{
	/// <summary>
	/// Summary description for Log.
	/// </summary>
	public class Log
	{
    TextWriter writer;

		private Log(string path)
		{
	    writer = StreamWriter.Synchronized(new StreamWriter(path, true));
		}

    
    static Log log = new Log(GetLogName());

    public static Log GetInstance() {
      return log;
    }

    private void WriteInternal(object logged, string format, params object[] arg) {
      string s = string.Format(format, arg);
      writer.WriteLine("ticks={3}, type={4}; hash={0}; thread={1}; message={2}" , logged.GetHashCode(), System.Threading.Thread.CurrentThread.GetHashCode(), s, DateTime.Now.Ticks, logged.GetType());
      writer.Flush();
    }

    public static void Write(object logged, string format, params object[] arg) {
      GetInstance().WriteInternal(logged, format, arg);
    }

    // this is disgustingly brittle
    static string GetLogName() {
      string filename = string.Format("firstfilter-{0:yyyyMMdd-hhmmss}.log", DateTime.Now);
      return HttpContext.Current.Server.MapPath(filename);
    }
	}
}
