using System;
using System.Web;

namespace OurFirstFilter {
  /// <summary>
  /// Summary description for Executing.
  /// </summary>
  public class ExecutingHandler : IHttpHandler {

    public void ProcessRequest(HttpContext context) {
      context.Server.Execute("default.aspx");
    }

    public bool IsReusable {
      get {
        return false;
      }
    }

  }
}
