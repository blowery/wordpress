using System;
using System.Web;

namespace OurFirstFilter
{
	/// <summary>
	/// Summary description for TransferringHandler.
	/// </summary>
	public class TransferringHandler : IHttpHandler {

    public void ProcessRequest(HttpContext context) {
      context.Server.Transfer("default.aspx");
    }

    public bool IsReusable {
      get {
        return false;
      }
    }

  }
}
