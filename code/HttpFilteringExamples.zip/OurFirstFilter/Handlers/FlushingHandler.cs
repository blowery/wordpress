using System;
using System.Web;

namespace OurFirstFilter
{
	/// <summary>
	/// A handler that writes two lines and flushes between them.
	/// </summary>
	public class FlushingHandler : IHttpHandler
	{
    public void ProcessRequest(HttpContext context) {
      HttpResponse response = context.Response;
      response.ContentType = "text/html";
      response.Write("<html><body><p>");
      response.Write("the first line<br>" + Environment.NewLine);
      response.Flush();
      response.Write("the second line" + Environment.NewLine);
      response.Write("</p></body></html>");
    }

    public bool IsReusable {
      get { return false; }
    }
  }
}
