using System;
using System.Web;

namespace OurFirstFilter
{
	/// <summary>
	/// Summary description for BrokenFilterInstallHandler.
	/// </summary>
	public class BrokenFilterInstallHandler : IHttpHandler
	{
    public void ProcessRequest(HttpContext context) {
      HttpResponse response = context.Response;
      
      TimestampFilter filter = new TimestampFilter(response.OutputStream);
      response.Filter = filter;

      response.ContentType = "text/html";
      response.Write("<html><body>Broken filter install!</body></html>");

    }

    public bool IsReusable {
      get {
        // TODO:  Add BrokenFilterInstallHandler.IsReusable getter implementation
        return false;
      }
    }
  }
}
