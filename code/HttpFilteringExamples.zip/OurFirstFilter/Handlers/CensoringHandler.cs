using System;
using System.Web;

namespace OurFirstFilter
{
	public class CensoringHandler : IHttpHandler {
    
    public void ProcessRequest(HttpContext context) {
      HttpResponse response = context.Response;
      response.Filter = new Catch22Filter(response.Filter, response.Output.Encoding);

      response.ContentType = "text/html";
      response.Write("<html><head><title>The Document</title></head><body>");
      response.Write("The first line!<br>The second line!!<br>A third line!!!");
      response.Write("</body></html>");
    }

    public bool IsReusable {
      get { return false; }
    }
  }
}
