using System;

namespace ImageToText
{
	/// <summary>
	/// Summary description for ImageToTextConverter.
	/// </summary>
	public class ImageToHtmlConverter
	{

    private const int DEFAULT_X_SAMPLE_SIZE = 4;
    private const int DEFAULT_Y_SAMPLE_SIZE = 6;
    private const int DEFAULT_FONT_PIXEL_HEIGHT = 8;

    private const char textPixel = '@';

    private int _xSampleSize = DEFAULT_X_SAMPLE_SIZE;
    private int _ySampleSize = DEFAULT_Y_SAMPLE_SIZE;
    private int _fontPixelHeight = DEFAULT_FONT_PIXEL_HEIGHT;

    System.Drawing.Bitmap _bitmap;
    System.IO.StreamWriter _writer;

    private bool _startedWritingColor = false;

    public ImageToHtmlConverter(
      System.Drawing.Bitmap bitmap, 
      System.IO.Stream outputStream): this(bitmap, outputStream, ImageToHtmlConverter.DEFAULT_X_SAMPLE_SIZE, ImageToHtmlConverter.DEFAULT_Y_SAMPLE_SIZE, ImageToHtmlConverter.DEFAULT_FONT_PIXEL_HEIGHT)
    {

    }

    public ImageToHtmlConverter(
      System.Drawing.Bitmap bitmap,
      System.IO.Stream outputStream,
      int xSampleSize,
      int ySampleSize) : this(bitmap, outputStream, xSampleSize, ySampleSize, ImageToHtmlConverter.DEFAULT_FONT_PIXEL_HEIGHT) {

    }

		public ImageToHtmlConverter(
      System.Drawing.Bitmap bitmap, 
      System.IO.Stream outputStream, 
      int xSampleSize, 
      int ySampleSize,
      int fontPixelHeight)
		{
      if(bitmap == null) 
        throw new ArgumentNullException("bitmap", "bitmap cannot be null.");
		  _bitmap = bitmap;

      if(outputStream == null)
        throw new ArgumentNullException("outputStream", "output stream cannot be null");
      else if(!outputStream.CanWrite)
        throw new ArgumentException("outputStream", "output stream must be writeable");
      _writer = new System.IO.StreamWriter(outputStream, System.Text.Encoding.UTF8);

      _xSampleSize = xSampleSize;
      _ySampleSize = ySampleSize;
      _fontPixelHeight = fontPixelHeight;
		}

    public void ParseImage() {
      _writer.WriteLine("<html><head>");
      _writer.WriteLine("<style>");
      _writer.WriteLine("PRE {{ font-size:{0}px; }}", _fontPixelHeight);
      _writer.WriteLine("</style></head>");
      _writer.WriteLine("<body bgcolor=\"black\">");
      _writer.WriteLine("<pre>");
      
      System.Drawing.Color[] colorBlock = new System.Drawing.Color[_xSampleSize * _ySampleSize];

      System.Drawing.Color previousColor = System.Drawing.Color.Empty;
      for(int y = 0; y+_ySampleSize < _bitmap.Height; y += _ySampleSize) {
        for(int x = 0; x+_xSampleSize < _bitmap.Width; x += _xSampleSize) {

          int z = 0;
          for(int innerY = 0; innerY < _ySampleSize; ++innerY) {
            for(int innerX = 0; innerX < _xSampleSize; ++innerX) {
              colorBlock[z++] = _bitmap.GetPixel(x+innerX, y+innerY);
            }
          }
          System.Drawing.Color ac = AverageColor(colorBlock);
          if(ac != previousColor) {
            EndWriteColor();
            StartWriteColor(ac);
            previousColor = ac;
          }
           
          _writer.Write(textPixel);
        }
        _writer.Write("\n");
      }

      EndWriteColor();

      _writer.WriteLine("</pre>"); 
      _writer.WriteLine("</body>");
      _writer.WriteLine("</html>");
      _writer.Flush();
    }

    private void StartWriteColor(System.Drawing.Color color) {
      _writer.Write("<font color=\"{0}\">", System.Drawing.ColorTranslator.ToHtml(color));
      _startedWritingColor = true;
    }

    private void EndWriteColor() {
      if(_startedWritingColor) {
        _writer.Write("</font>");
        _startedWritingColor = false;
      }
    }

    private System.Drawing.Color AverageColor(System.Drawing.Color[] colors) {
      int r=0;
      int g=0;
      int b=0;
      int total = colors.Length;

      for(int i = 0; i < colors.Length; ++i) {
        r += colors[i].R;
        g += colors[i].G;
        b += colors[i].B;
      }

      return System.Drawing.Color.FromArgb(r / total, g / total, b / total);

    }                                 

	}
}
