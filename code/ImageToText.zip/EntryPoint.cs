using System;

namespace ImageToText
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class EntryPoint
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
      if(args.Length < 2) {
        WriteUsage();
        return;
      }


      System.Drawing.Bitmap image = null;
      System.IO.FileStream outputFile = null;
      int xScale = 4;
      int yScale = 6;

      if(args.Length >= 3) {
        xScale = int.Parse(args[2]);
      }
      if(args.Length == 4) {
        yScale = int.Parse(args[3]);
      }

      try {
        image = new System.Drawing.Bitmap(System.Drawing.Bitmap.FromFile(args[0]));
        outputFile = new System.IO.FileStream(args[1], System.IO.FileMode.Create, System.IO.FileAccess.Write);
        ImageToHtmlConverter converter = new ImageToHtmlConverter(image, outputFile, xScale, yScale);
        converter.ParseImage();
      }
      catch(Exception e) {
        WriteError(e);
        return;
      }
      finally {
        if(image != null) {
          image.Dispose();
        }
        if(outputFile != null) {
          outputFile.Close();
        }
      }

		}

    static void WriteUsage() {
      Console.WriteLine("usage: ImageToText <img file> <output file> [xScale] [yScale]");
      Console.WriteLine("  img file    : a file containing an image to parse");
      Console.WriteLine("  output file : a file to write the html out to.  overwrites any existing");
      Console.WriteLine("  xScale      : how many real pixels along the x-axis to sample for one text 'pixel' (optional)");
      Console.WriteLine("  yScale      : how many real pixels along the y-axix to sample for one text 'pixel' (optional)");
    }

    static void WriteError(Exception e) {
      Console.WriteLine("Something bad happened.");
      Console.WriteLine(e);
    }


	}
}
