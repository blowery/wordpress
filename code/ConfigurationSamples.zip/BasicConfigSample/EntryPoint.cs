using System;
using System.Configuration;

namespace BasicConfigSample 
{
  class EntryPoint 
  {
    [STAThread]
    static void Main(string[] args) {
      BasicSettings settings = BasicSettings.GetSettings();
      Console.WriteLine("The configured name is {0}", settings);
    }
  }
}
