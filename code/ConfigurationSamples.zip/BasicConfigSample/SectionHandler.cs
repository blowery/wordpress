using System;
using System.Configuration;
using System.Xml;

namespace BasicConfigSample
{
	class SectionHandler : IConfigurationSectionHandler
	{
    public object Create(object parent, 
                         object context, 
                         XmlNode section) 
    {
      string f = section["firstName"].InnerText;
      string l = section["lastName"].InnerText;
      return new BasicSettings(f,l);
    }
	}
}
