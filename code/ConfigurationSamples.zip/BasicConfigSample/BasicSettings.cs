using System;
using System.Configuration;
using cs = System.Configuration.ConfigurationSettings;
using System.Xml.Serialization;

namespace BasicConfigSample
{
	public class BasicSettings
	{
    const string section = "blowery.org/basics";

    internal BasicSettings(string first, string last) {
      FirstName = first;
      LastName = last;
    }

    private BasicSettings() {
      FirstName = "<<not";
      LastName = "set>>";
    }

    public readonly string FirstName;
    public readonly string LastName;

    public override string ToString() {
      return FirstName + " " + LastName;
    }

    public static BasicSettings GetSettings() {
      BasicSettings b = (BasicSettings)cs.GetConfig(section);
      
      if(b == null)
        return new BasicSettings();
      else
        return b;
    }
	}
}
