using System;
using System.Configuration;
using System.Xml;

namespace ParentingSample
{
  class SectionHandler : IConfigurationSectionHandler {
    public object Create(object parent, 
      object context, 
      XmlNode section) {
      int num = int.Parse(section.Attributes["value"].Value);
      
      if(parent == null)
        return new Settings(num);

      Settings b = (Settings)parent;
      b.Add(num);

      return b;
    }
  }
}
