using System;
using System.Configuration;
using cs = System.Configuration.ConfigurationSettings;
using System.Xml.Serialization;

namespace ParentingSample
{
  public class Settings {
    const string section = "blowery.org/sum";

    private int sum = 0;

    internal Settings(int start) {
      sum = start;
    }

    private Settings() {
      sum = 0;
    }

    public int Total { 
      get { return sum; } 
    }

    internal int Add(int a) { 
      return sum += a; 
    } 
        
    public override string ToString() {
      return Total.ToString();
    }

    public static Settings GetSettings() {
      Settings b = (Settings)cs.GetConfig(section);
      
      if(b == null)
        return new Settings();
      else
        return b;
    }
    
	}
}
