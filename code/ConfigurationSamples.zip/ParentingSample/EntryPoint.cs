using System;
using System.Configuration;

namespace ParentingSample 
{
  class EntryPoint 
  {
    [STAThread]
    static void Main(string[] args) {
      Settings settings = Settings.GetSettings();
      Console.WriteLine("The sum of all config sections is {0}", settings);
    }
  }
}
