using System;

namespace org.blowery {
  /// <summary>
  /// Little class to encapsulate hashing a string given a salt and some other info
  /// </summary>
  public class StringHasher : IDisposable {

    byte[] _salt;  // the salt for the hash.  always put in front of the real text
    System.Security.Cryptography.HashAlgorithm _hasher;  // the hashing algorithm to use
    System.Text.Encoding _encoding;  // the text encoding to use.  this determines how you convert to a byte[] from a string

    /// <summary>
    /// Construct a string hasher
    /// </summary>
    /// <param name="salt">the salt to use with the hash</param>
    /// <param name="hasher">the algorithm to use to perform the hash</param>
    /// <param name="encoding">the encoding mechanism to use to convert the string to a Byte[]</param>
    public StringHasher(byte[] salt, System.Security.Cryptography.HashAlgorithm hasher, System.Text.Encoding encoding) {

      if(hasher == null)
        throw new ArgumentNullException("hasher", "Must pass in a valid hash algorithm");

      if(encoding == null)
        throw new ArgumentNullException("encoding", "Must pass in a valid encoding");

      if(salt == null)
        _salt = new byte[0];
      else
        _salt = salt;
      
      _hasher = hasher; 
      _encoding = encoding;
    
    }

    // <summary>
    /// Construct a string hasher
    /// </summary>
    /// <param name="salt">the salt to use with the hash</param>
    public StringHasher(byte[] salt) : this(salt, System.Security.Cryptography.MD5.Create(), System.Text.Encoding.ASCII) { }

    /// <summary>
    /// Implementation of IDisposable.Dispose.  Let's go of managed resources inside the class.
    /// </summary>
    public void Dispose() {
      if(!disposed)
        ((IDisposable)_hasher).Dispose();
    }
    private bool disposed = false;

    /// <summary>
    /// Calculate a hash of the given string
    /// </summary>
    /// <param name="hashme">the string to hash</param>
    /// <returns>a Byte[] representing the hashed (salt+string)</returns>
    public byte[] GetHash(string hashme) {
      
      if(disposed)
        throw new ObjectDisposedException(this.ToString(), "Sorry, object has been disposed.  Please create a new one.");

      byte[] bytesToHash = new byte[_salt.Length + _encoding.GetByteCount(hashme)];
      
      _salt.CopyTo(bytesToHash,0);
      _encoding.GetBytes(hashme, 0, hashme.Length, bytesToHash, _salt.Length);
      
      return _hasher.ComputeHash(bytesToHash);
    }

    [STAThread()]
    static void Main(string[] args) {
      if(args.Length == 0) 
        Console.WriteLine("usage: StringHasher <stringToHash> [<stringToHash>] [...]");


      byte[] mySalt = new byte[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

      System.Collections.ArrayList hashers = new System.Collections.ArrayList();
      hashers.Add(new StringHasher(mySalt, System.Security.Cryptography.SHA256Managed.Create(), System.Text.Encoding.ASCII));
      hashers.Add(new StringHasher(mySalt, System.Security.Cryptography.SHA256Managed.Create(), System.Text.Encoding.Unicode));

      hashers.Add(new StringHasher(mySalt, System.Security.Cryptography.MD5.Create(), System.Text.Encoding.ASCII));
      hashers.Add(new StringHasher(mySalt, System.Security.Cryptography.MD5.Create(), System.Text.Encoding.Unicode));
      hashers.Add(new StringHasher(mySalt, System.Security.Cryptography.MD5.Create(), System.Text.Encoding.UTF8));
      

      foreach(string s in args) {

        foreach(StringHasher hasher in hashers) {
          Console.WriteLine("Hashing {0} using {1} and {2}", s, hasher._hasher, hasher._encoding);
          OutputUtils.PrintByteArray(hasher.GetHash(s));
          Console.WriteLine();
          Console.WriteLine();
        }
      }
    }

    
  }

  /// <summary>
  /// Silly internal class used for outputting byte arrays
  /// </summary>
  internal class OutputUtils {
    private OutputUtils() {  }

    public static void PrintByteArray(byte[] bytes) {
      foreach(byte b in bytes) {
        Console.Write("{0:x2}", b);
      }
    }
  }
}
