using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace StringCrypto {
  
  /// <summary>
  /// Allows you to transform a string to and from an encrypted form
  /// </summary>
  public class StringTransformer : IDisposable {

    private ICryptoTransform encryptingTransform;
    private ICryptoTransform decryptingTransform;

    public StringTransformer() {

      // this is the key you're going to use for the encryption.
      // there are better ways to get a key, but this is convienen
      byte[] tempKey = Encoding.ASCII.GetBytes("PASSWORDPASSWORD");

      // this is the initialization vector that you're going to seed your
      // encryption / decryption with.  this is only needed if you
      // use a CBC, CTS, or CFB chaining.  If you use ECB, it will
      // be ignored.  CBC is a good choice.
      byte[] tempIV = Encoding.ASCII.GetBytes("0000000000000000");

      // create the rijndael algo and encryptor / decryptor
      // you can easily flip this out to use triple des, though you'll
      // have to change the size of your key and iv to match the
      // required block size for triple des.
      // Rijndael is quicker and more secure than triple des, so i'm using
      // it instead.
      using (SymmetricAlgorithm algo = new RijndaelManaged()) {
      
        // use cipher block chaining mode.  most secure.
        algo.Mode = CipherMode.CBC;

        // use pkcs7 padding.  padding happens when you write out less than a 
        // full encryption block to your cryptostream.  Zeros padding doesn't
        // work right in V1..
        algo.Padding = PaddingMode.PKCS7;
        algo.Key = tempKey;
        algo.IV = tempIV;
      
        // create a cryptor and decryptor for use later.  could do this on demand and
        // cache the algo instead, but this is pretty easy.
        encryptingTransform = algo.CreateEncryptor();
        decryptingTransform = algo.CreateDecryptor();
      }
    }

    // marker to determine if i've been disposed off
    private bool disposed = false;

    // allows consumers of this class to free up internal stuff early
    public void Dispose() {
      if(!disposed) {
        encryptingTransform.Dispose();
        decryptingTransform.Dispose();
        disposed = true;
      }
    }

    /// <summary>
    /// Encrypt a string
    /// </summary>
    /// <param name="plainText">the text to encrypt</param>
    /// <returns>an encrypted, base64-encoded version of the plaintext</returns>
    public string Encrypt(string plainText) {

      // can't use if disposed
      if(disposed)
        throw new ObjectDisposedException(base.ToString(), "This object has been disposed.  You cannot use it further.");
      
      // make a new memory stream to write the encrypted stream into.
      // setting the intial size to be the same as the plaintext.  that's actually
      // going to be too small, but it's a good starting point.
      using(MemoryStream outputStream = new MemoryStream(plainText.Length)) {

        // setup a new cryptostream to write into
        using(CryptoStream encryptingStream = new CryptoStream(outputStream, encryptingTransform, CryptoStreamMode.Write)) {
          
          // buffer to hold the byte[] version of the text.  use a different encoding if you need
          // better fidelity for your strings
          byte[] inputBuffer = Encoding.ASCII.GetBytes(plainText);

          // write out some debugging fun
          Debug.WriteLine("Source:");
          DebugHelper.PrintByteArray(inputBuffer);

          // write out my stuff to the crypto stream
          encryptingStream.Write(inputBuffer, 0, inputBuffer.Length);

          // flush to pad out any remaining bytes and flush the streams
          encryptingStream.FlushFinalBlock();
                        
          // more debug writes
          Debug.WriteLine("Encrypted Bytes:");
          DebugHelper.PrintByteArray(outputStream.ToArray());

          // convert it to base64 so that you have printable characters.
          return Convert.ToBase64String(outputStream.ToArray());
        }
      }
    }
   
    /// <summary>
    /// Decrypt a string
    /// </summary>
    /// <param name="cipherText">the base64-encoded, encrypted string to decrypt</param>
    /// <returns>the plaintext version of the cipherText</returns>
    public string Decrypt(string cipherText) {

      // can't use it is you've already disposed it
      if(disposed)
        throw new ObjectDisposedException(base.ToString(), "This object has been disposed.  You cannot use it further.");

      // put the ciphertext into a memory stream so we can work with it
      using(MemoryStream cipherStream = new MemoryStream(Convert.FromBase64String(cipherText))) {

        // alloc a new buffer to write the plaintext into.  at worst, it'll be as big as the ciphertext
        byte[] outputBuffer = new byte[cipherText.Length];

        // make a cryptostream for decryption
        using(CryptoStream decryptingStream = new CryptoStream(cipherStream, decryptingTransform, CryptoStreamMode.Read)) {


          // write some debugging stuff
          // these bytes should match the Encrypted bytes from the Encrypt method
          Debug.WriteLine("Encrypted Bytes:");
          DebugHelper.PrintByteArray(Convert.FromBase64String(cipherText));

          // read stuff out of the decrypting stream into the buffer.  try to read the cipherText's length, which
          // is probably too long.  you can figure out how many bytes were read by capturing the return value
          // of this call...
          decryptingStream.Read(outputBuffer, 0, (int)cipherStream.Length);


          // more debugging fun.  should match source bytes from above
          Debug.WriteLine("Decrypted Bytes:");
          DebugHelper.PrintByteArray(outputBuffer);

          // match this encoding to the encoding above.  could create a member instance, but i'm lazy right now.
          return Encoding.ASCII.GetString(outputBuffer);
        }
      }
    }

  } 

  
  // this is a silly class
  class DebugHelper {

    // not mean to be instantiated
    private DebugHelper() {}
  
    /// <summary>
    /// Silly helper function to spit out byte arrays nicely
    /// </summary>
    /// <param name="arr">the byte array to spit out</param>
    public static void PrintByteArray(Byte[] arr) {
      int i;
      Debug.WriteLine("Length: " + arr.Length);
      
      for (i=0; i<arr.Length; ++i) {
        Debug.Write(String.Format("{0:X}", arr[i]));
        Debug.Write("    ");
        
        if ( (i+9)%8 == 0 ) 
          Debug.WriteLine(string.Empty);
      }
      if (i%8 != 0) 
        Debug.WriteLine(string.Empty);
    }

  }
  

}
