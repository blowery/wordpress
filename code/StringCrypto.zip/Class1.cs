using System;

namespace StringCrypto
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			StringTransformer transform = new StringTransformer();
      
      foreach(string s in args) {
        Console.WriteLine("Encrypting {0}:", s);
        
        string encrypted = transform.Encrypt(s);
        Console.WriteLine(" {0}", encrypted);
        Console.WriteLine();

        string decrypted = transform.Decrypt(encrypted);
        Console.WriteLine("Decrypting {0}:", encrypted);
        Console.WriteLine(" {0}", decrypted);

        if(decrypted.CompareTo(s) == 0)
          Console.WriteLine("Strings are equivalent, Encryption worked!");
        else
          Console.WriteLine("String are not equivalent.  Something bad happened");
        
        Console.WriteLine();
      }
		}
	}
}
