Hey there,

Thanks for downloading my compressing filter for ASP.NET!  As
you can see, the full source is provided so you can 
understand how it works and modify it if you want.

If you don't have visual studio, no fear.  The whole project
lives in one directory, so csc *.cs should work, you just need
to add a reference to the supplied NZipLib.dll.

To get you going, read the docs on msdn regarding HttpModules.
That's how this thing works, as an HttpModule.  An HttpModule
is a little chunk of code that gets slipped into the HttpRuntime
via the web.config file.  It hooks an event in the HttpApplication
object and responds to it.

For instructions on how to slip the HttpCompressing module in,
see the provided web.config file.  It shows what entries have
to be added to the web.config to set things up.

So, to get things going, here's what you have to do:
1) compile the project into a library
2) move the .dll that comes from compilation to the /bin directory of
   your asp.net web app
3) add the entries to the web.config of your asp.net app

That's it.  That should get you going.

--b