using System;
using System.Xml;
using System.Xml.Serialization;

namespace blowery.Web.HttpModules
{
	/// <summary>
	/// Summary description for ConfigSectionHandler.
	/// </summary>
	internal class ConfigSectionHandler : System.Configuration.IConfigurationSectionHandler
	{
    
    /// <summary>
    /// Create a new config section handler
    /// </summary>
    object System.Configuration.IConfigurationSectionHandler.Create(object parent, object configContext, XmlNode configSection) {
      return configSection;
    }
	}

}
