using System;
using System.Xml;
using System.Xml.XPath;

namespace XmlFileEntities
{
	class EntryPoint
	{
		[STAThread]
		static void Main(string[] args)
		{
	    XmlValidatingReader reader = new XmlValidatingReader(new XmlTextReader(args[0]));
      reader.ValidationType = ValidationType.None;

      Console.WriteLine("CanResolveEntity: {0}", reader.CanResolveEntity);

      XPathDocument doc = new XPathDocument(reader);
      XPathNavigator nav = doc.CreateNavigator();
      XPathNodeIterator i = nav.Select("/projects/project");
      while(i.MoveNext()) {
        Console.WriteLine(i.Current.ToString());
      }
		}
	}
}
