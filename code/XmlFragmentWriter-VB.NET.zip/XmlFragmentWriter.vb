Imports System.Xml
Imports System.IO
Imports System.Text

Class XmlFragmentWriter
  Inherits XmlTextWriter

  Public Sub New(ByVal w As TextWriter)
    MyBase.new(w)
  End Sub

  Public Sub New(ByVal w As Stream, ByVal encoding As Encoding)
    MyBase.new(w, encoding)
  End Sub

  Public Sub New(ByVal filename As String, ByVal encoding As Encoding)
    MyBase.new(New FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None), encoding)
  End Sub


  Private _skip As Boolean = False

  Public Overloads Overrides Sub WriteStartAttribute(ByVal prefix As String, ByVal localName As String, ByVal ns As String)


    ' STEP 1 - Omits XSD and XSI declarations.
    ' From Kzu - http://weblogs.asp.net/cazzu/archive/2004/01/23/62141.aspx

        if prefix = "xmlns" andalso ( localName = "xsd" orelse localName = "xsi" ) then

      _skip = True

      Return

    End If

    MyBase.WriteStartAttribute(prefix, localName, ns)

  End Sub



  Public Overrides Sub WriteString(ByVal text As String)

    If _skip Then Return

    MyBase.WriteString(text)

  End Sub



  Public Overrides Sub WriteEndAttribute()

    If _skip Then

      ' Reset the flag, so we keep writing.

      _skip = False

      Return

    End If

    MyBase.WriteEndAttribute()

  End Sub



  Public Overrides ReadOnly Property WriteState() As WriteState

    Get

      ' STEP 2: Omit the xml declaration.

      Dim ws As WriteState = MyBase.WriteState

      ' If it in Start position, lie and say we're already at the Prolog

      If ws = WriteState.Start Then Return WriteState.Prolog

      Return ws

    End Get

  End Property

End Class