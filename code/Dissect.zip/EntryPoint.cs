using System;
using System.IO;
using System.Runtime.InteropServices;

using System.Xml.Serialization;

namespace Dissect
{
	class EntryPoint
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static int Main(string[] args)
		{
      if(args.Length != 1 || !File.Exists(args[0])) {
        Console.WriteLine("Must provide an assembly to dissect.");
        return -1; 
      }

      XmlSerializer xmlout = new XmlSerializer(typeof(PeCoffImage));

      PECoffReader reader = new PECoffReader(args[0]);
      PeCoffImage image = new PeCoffImage();
      image.DosHeader = reader.ReadImageHeader();
      image.PeHeader = reader.ReadNtHeaders();
      image.Sections = reader.ReadSections();
      image.ClrHeader = reader.ReadClrHeader();

      xmlout.Serialize(Console.Out, image);
      

      return 0;
      
		}
	}

  public class PeCoffImage {
    public ImageDosHeader DosHeader;
    public ImageNtHeaders32 PeHeader;
    public ImageSection[] Sections;
    public ImageCor20Header ClrHeader;
  }
}
