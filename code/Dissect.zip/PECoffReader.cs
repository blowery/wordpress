using System;
using System.IO;


namespace Dissect
{
	/// <summary>
	/// A nice little class that will give reader access over a PE/Coff file
	/// </summary>
	public class PECoffReader : IDisposable
	{
    BinaryReader reader;

    ImageDosHeader header;
    ImageNtHeaders32 ntHeaders;
    ImageCor20Header corHeader;
    ImageSection[] sections;

		public PECoffReader(string filename)
		{
			reader = new BinaryReader(new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read));
    }

    public ImageDosHeader ReadImageHeader() {
      header = new ImageDosHeader();
      
      header.Magic = reader.ReadUInt16();
      header.BytesOnLastPage = reader.ReadUInt16();
      header.Pages = reader.ReadUInt16();
      header.Relocations = reader.ReadUInt16();
      header.ParagraphsInHeader = reader.ReadUInt16();
      header.MinExtraParagraphs = reader.ReadUInt16();
      header.MaxExtraParagraphs = reader.ReadUInt16();
      header.InitialSS = reader.ReadUInt16();
      header.InitialSP = reader.ReadUInt16();
      header.Checksum = reader.ReadUInt16();
      header.InitialIP = reader.ReadUInt16();
      header.InitialCS = reader.ReadUInt16();
      header.AddressOfRelocationTable = reader.ReadUInt16();
      header.OverlayNumber = reader.ReadUInt16();
      header.ReservedWords = new ushort[4];
      header.ReservedWords[0] = reader.ReadUInt16();
      header.ReservedWords[1] = reader.ReadUInt16();
      header.ReservedWords[2] = reader.ReadUInt16();
      header.ReservedWords[3] = reader.ReadUInt16();
      header.OemId = reader.ReadUInt16();
      header.OemInfo = reader.ReadUInt16();

      header.ReservedWords2 = new ushort[10];
      header.ReservedWords2[0] = reader.ReadUInt16();
      header.ReservedWords2[1] = reader.ReadUInt16();
      header.ReservedWords2[2] = reader.ReadUInt16();
      header.ReservedWords2[3] = reader.ReadUInt16();
      header.ReservedWords2[4] = reader.ReadUInt16();
      header.ReservedWords2[5] = reader.ReadUInt16();
      header.ReservedWords2[6] = reader.ReadUInt16();
      header.ReservedWords2[7] = reader.ReadUInt16();
      header.ReservedWords2[8] = reader.ReadUInt16();
      header.ReservedWords2[9] = reader.ReadUInt16();

      header.AddressOfNewExeHeader = reader.ReadInt32();

      return header;
    }

    public ImageNtHeaders32 ReadNtHeaders() {
      if(header == null) ReadImageHeader();

      reader.BaseStream.Seek(header.AddressOfNewExeHeader, SeekOrigin.Begin);
      
      ntHeaders = new ImageNtHeaders32();

      ntHeaders.Signature = reader.ReadUInt32();
      
      ImageFileHeader fileHeader = new ImageFileHeader();
      fileHeader.Machine = reader.ReadUInt16();
      fileHeader.NumberOfSections = reader.ReadUInt16();
      fileHeader.TimeDateStamp = reader.ReadUInt32();
      fileHeader.PointerToSymbolStore = reader.ReadUInt32();
      fileHeader.NumberOfSymbols = reader.ReadUInt32();
      fileHeader.SizeOfOptionalHeader = reader.ReadUInt16();
      fileHeader.Characteristics = reader.ReadUInt16();
      ntHeaders.FileHeader = fileHeader;

      ImageOptionalHeader32 opt = new ImageOptionalHeader32();
      opt.Magic = reader.ReadUInt16();
      opt.MajorLinkerVersion = reader.ReadByte();
      opt.MinorLinkerVersion = reader.ReadByte();
      opt.SizeOfCode = reader.ReadUInt32();
      opt.SizeOfInitializedData = reader.ReadUInt32();
      opt.SizeOfUninitializedData = reader.ReadUInt32();
      opt.AddressOfEntryPoint = reader.ReadUInt32();
      opt.BaseOfCode = reader.ReadUInt32();
      opt.BaseOfData = reader.ReadUInt32();
      opt.ImageBase = reader.ReadUInt32();
      opt.SectionAlignment = reader.ReadUInt32();
      opt.FileAlignment = reader.ReadUInt32();
      opt.MajorOperatingSystemVersion = reader.ReadUInt16();
      opt.MinorOperatingSystemVersion = reader.ReadUInt16();
      opt.MajorImageVersion = reader.ReadUInt16();
      opt.MinorImageVersion = reader.ReadUInt16();
      opt.MajorSubsystemVersion = reader.ReadUInt16();
      opt.MinorSubsystemVersion = reader.ReadUInt16();
      opt.Win32VersionValue = reader.ReadUInt32();
      opt.SizeOfImage = reader.ReadUInt32();
      opt.SizeOfHeaders = reader.ReadUInt32();
      opt.CheckSum = reader.ReadUInt32();
      opt.Subsystem = reader.ReadUInt16();
      opt.DllCharacteristics = reader.ReadUInt16();
      opt.SizeOfStackCommit = reader.ReadUInt32();
      opt.SizeOfStackReserve = reader.ReadUInt32();
      opt.SizeOfHeapReserve = reader.ReadUInt32();
      opt.SizeOfHeapCommit = reader.ReadUInt32();
      opt.LoaderFlags = reader.ReadUInt32();
      opt.NumberOfRvaAndSizes = reader.ReadUInt32();

      opt.DataDirectories = new ImageDataDirectory[16];
      for(int i = 0; i < 16; ++i) {
        opt.DataDirectories[i] = ReadDataDirectory();
      }

      ntHeaders.OptionalHeader = opt;

      return ntHeaders;
    }

    public ImageSection[] ReadSections() {
      if(ntHeaders == null) ReadNtHeaders();
      sections = new ImageSection[ntHeaders.FileHeader.NumberOfSections];

      for(int i=0; i < ntHeaders.FileHeader.NumberOfSections; ++i) {
        sections[i] = ReadSection();
      }
      return sections;
    }

    public ImageSection ReadSection() {
      ImageSection sec = new ImageSection();
      byte[] buf = new byte[8];
      reader.BaseStream.Read(buf, 0, 8);
      int i=0;
      for(i = 0; i < 8; ++i)
        if(buf[i] == 0) break;
      sec.Name = System.Text.Encoding.ASCII.GetString(buf, 0, i);
      sec.VirtualSize = reader.ReadUInt32();
      sec.VirtualAddress = reader.ReadUInt32();
      sec.SizeOfRawData = reader.ReadUInt32();
      sec.PointerToRawData = reader.ReadUInt32();
      sec.PointerToRelocations = reader.ReadUInt32();
      sec.PointerToLineNumbers = reader.ReadUInt32();
      sec.NumberOfRelocations = reader.ReadUInt16();
      sec.PointerToLineNumbers = reader.ReadUInt16();
      sec.Characteristics = reader.ReadUInt32();
      return sec;
    }

    public ImageCor20Header ReadClrHeader() {
      if(ntHeaders == null) ReadSections();

      reader.BaseStream.Seek(RvaToVa(ntHeaders.OptionalHeader.DataDirectories[ImageOptionalHeader32.IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR].VirtualAddress), SeekOrigin.Begin);

      corHeader = new ImageCor20Header();

      corHeader.SizeOfHeader = reader.ReadUInt32();
      corHeader.MajorRuntimeVersion = reader.ReadUInt16();
      corHeader.MinorRuntimeVersion = reader.ReadUInt16();
      corHeader.MetaData = ReadDataDirectory();
      corHeader.Flags = reader.ReadUInt32();
      corHeader.EntryPointToken = reader.ReadUInt32();
      corHeader.Resources = ReadDataDirectory();
      corHeader.StrongNameSignature = ReadDataDirectory();
      corHeader.CodeManagerTable = ReadDataDirectory();
      corHeader.VTableFixups = ReadDataDirectory();
      corHeader.ExportAddressTableJumps = ReadDataDirectory();
      corHeader.ManagedNativeHeader = ReadDataDirectory();

      return corHeader;
      
    }

    ImageDataDirectory ReadDataDirectory() {
      ImageDataDirectory dir = new ImageDataDirectory();
      dir.VirtualAddress = reader.ReadUInt32();
      dir.Size = reader.ReadUInt32();
      return dir;
    }

    private uint RvaToVa(uint rva) {
      for(int i=0; i < sections.Length; ++i) {
        if(rva > sections[i].VirtualAddress && rva < sections[i].VirtualAddress + sections[i].SizeOfRawData)
          return rva + (sections[i].PointerToRawData - sections[i].VirtualAddress);
      }
      throw new ApplicationException("unknown RVA! " + rva.ToString());
    }

    #region IDisposable Members

    public void Dispose() {
      if(reader != null) 
        reader.Close();
    }

    #endregion
  }
}
