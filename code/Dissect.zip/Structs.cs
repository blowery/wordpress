using System;
using System.Runtime.InteropServices;

namespace Dissect {
  public class ImageDosHeader {      // DOS .EXE header
    public ushort   Magic;                     // Magic number
    public ushort   BytesOnLastPage;                      // Bytes on last page of file
    public ushort   Pages;                        // Pages in file
    public ushort   Relocations;                      // Relocations
    public ushort   ParagraphsInHeader;                   // Size of header in paragraphs
    public ushort   MinExtraParagraphs;                  // Minimum extra paragraphs needed
    public ushort   MaxExtraParagraphs;                  // Maximum extra paragraphs needed
    public ushort   InitialSS;                        // Initial (relative) SS value
    public ushort   InitialSP;                        // Initial SP value
    public ushort   Checksum;                      // Checksum
    public ushort   InitialIP;                        // Initial IP value
    public ushort   InitialCS;                        // Initial (relative) CS value
    public ushort   AddressOfRelocationTable;                    // File address of relocation table
    public ushort   OverlayNumber;                     // Overlay number
    public ushort[]   ReservedWords;                    // Reserved words
    public ushort   OemId;                     // OEM identifier (for e_oeminfo)
    public ushort   OemInfo;                   // OEM information; e_oemid specific
    public ushort[]   ReservedWords2;                  // Reserved words
    public int   AddressOfNewExeHeader;                    // File address of new exe header

    public const ushort IMAGE_DOS_SIGNATURE = 0x5A4D;      // MZ
    public const ushort IMAGE_OS2_SIGNATURE = 0x454E;      // NE
    public const ushort IMAGE_OS2_SIGNATURE_LE = 0x454C;      // LE
    public const ushort IMAGE_VXD_SIGNATURE = 0x454C;      // LE
  }

  public class ImageNtHeaders32 {
    public uint Signature;
    public ImageFileHeader FileHeader;
    public ImageOptionalHeader32 OptionalHeader;
    
  }

  public class ImageFileHeader {
    public ushort Machine;
    public ushort NumberOfSections;
    public uint TimeDateStamp;
    public uint PointerToSymbolStore;
    public uint NumberOfSymbols;
    public ushort SizeOfOptionalHeader;
    public ushort Characteristics;
  }

  public class ImageOptionalHeader32 {
    public ushort Magic;
    public byte MajorLinkerVersion;
    public byte MinorLinkerVersion;
    public uint SizeOfCode;
    public uint SizeOfInitializedData;
    public uint SizeOfUninitializedData;
    public uint AddressOfEntryPoint;
    public uint BaseOfCode;
    public uint BaseOfData;

    public uint ImageBase;
    public uint SectionAlignment;
    public uint FileAlignment;
    public ushort MajorOperatingSystemVersion;
    public ushort MinorOperatingSystemVersion;
    public ushort MajorImageVersion;
    public ushort MinorImageVersion;
    public ushort MajorSubsystemVersion;
    public ushort MinorSubsystemVersion;
    public uint Win32VersionValue;
    public uint SizeOfImage;
    public uint SizeOfHeaders;
    public uint CheckSum;
    public ushort Subsystem;
    public ushort DllCharacteristics;
    public uint SizeOfStackReserve;
    public uint SizeOfStackCommit;
    public uint SizeOfHeapReserve;
    public uint SizeOfHeapCommit;
    public uint LoaderFlags;
    public uint NumberOfRvaAndSizes;
    public ImageDataDirectory[] DataDirectories;

    public const int IMAGE_DIRECTORY_ENTRY_EXPORT         = 0;   // Export Directory
    public const int IMAGE_DIRECTORY_ENTRY_IMPORT         = 1;   // Import Directory
    public const int IMAGE_DIRECTORY_ENTRY_RESOURCE       = 2;   // Resource Directory
    public const int IMAGE_DIRECTORY_ENTRY_EXCEPTION      = 3;   // Exception Directory
    public const int IMAGE_DIRECTORY_ENTRY_SECURITY       = 4;   // Security Directory
    public const int IMAGE_DIRECTORY_ENTRY_BASERELOC      = 5;   // Base Relocation Table
    public const int IMAGE_DIRECTORY_ENTRY_DEBUG          = 6;   // Debug Directory
    public const int IMAGE_DIRECTORY_ENTRY_COPYRIGHT     =  7;   // (X86 usage)
    public const int IMAGE_DIRECTORY_ENTRY_ARCHITECTURE   = 7;   // Architecture Specific Data
    public const int IMAGE_DIRECTORY_ENTRY_GLOBALPTR      = 8;   // RVA of GP
    public const int IMAGE_DIRECTORY_ENTRY_TLS            = 9;   // TLS Directory
    public const int IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG   = 10;   // Load Configuration Directory
    public const int IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT  = 11;   // Bound Import Directory in headers
    public const int IMAGE_DIRECTORY_ENTRY_IAT           = 12;   // Import Address Table
    public const int IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT  = 13;   // Delay Load Import Descriptors
    public const int IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR = 14;   // COM Runtime descriptor
  }

  public class ImageDataDirectory {
    public uint VirtualAddress;
    public uint Size;
  }

  public class ImageCor20Header {
    public uint SizeOfHeader;
    public ushort MajorRuntimeVersion;
    public ushort MinorRuntimeVersion;
    public ImageDataDirectory MetaData;
    public uint Flags;
    public uint EntryPointToken;
    public ImageDataDirectory Resources;
    public ImageDataDirectory StrongNameSignature;
    public ImageDataDirectory CodeManagerTable;
    public ImageDataDirectory VTableFixups;
    public ImageDataDirectory ExportAddressTableJumps;
    public ImageDataDirectory ManagedNativeHeader;
  }

  public class ImageSection {
    public string Name;
    public uint VirtualSize;
    public uint VirtualAddress;
    public uint SizeOfRawData;
    public uint PointerToRawData;
    public uint PointerToRelocations;
    public uint PointerToLineNumbers;
    public ushort NumberOfRelocations;
    public ushort NumberOfLineNumbers;
    public uint Characteristics;
  }
}
