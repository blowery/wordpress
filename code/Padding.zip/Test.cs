using System;
using System.IO;
using System.Security.Cryptography;


namespace Padding
{
	/// <summary>
	/// A little class to test padding
	/// </summary>
	class EntryPoint
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{

      if(args.Length != 3) {
        Console.WriteLine("usage: Test <padding> <cipher> <plaintext>");
        Console.WriteLine("  padding    : padding mode");
        Console.WriteLine("  cipher     : cipher chaining mode");
        Console.WriteLine("  plaintext  : the text to encrypt");
      }

      using(SymmetricAlgorithm algo = new RijndaelManaged()) {
        algo.GenerateIV();
        algo.GenerateKey();
        algo.Padding = GetPaddingModeFromString(args[0]);
        algo.Mode = GetCipherModeFromString(args[1]);

        using(MemoryStream outputBuffer = new MemoryStream()) {
          using(CryptoStream fun = new CryptoStream(outputBuffer, algo.CreateEncryptor(), CryptoStreamMode.Write)) {
            
            byte[] encryptMe = System.Text.Encoding.ASCII.GetBytes(args[2]);
      
            fun.Write(encryptMe, 0, encryptMe.Length); 
            fun.FlushFinalBlock();

            PrintByteArray(outputBuffer.ToArray());
          }
        }
      }
		}

    static CipherMode GetCipherModeFromString(string cipherMode) {
      switch(cipherMode.ToLower()) {
        case "cbc":
          return CipherMode.CBC;
        case "cfb":
          return CipherMode.CFB;
        case "cts":
          return CipherMode.CTS;
        case "ecb":
          return CipherMode.ECB;
        case "ofb":
          return CipherMode.OFB;
        default:
          throw new ArgumentException("cipherMode is not a supported cipher mode", "cipherMode");
      }
    }

    static PaddingMode GetPaddingModeFromString(string paddingMode) {
      switch(paddingMode.ToLower()) {
        case "none":
          return PaddingMode.None;
        case "zeros":
          return PaddingMode.Zeros;
        case "pkcs7":
          return PaddingMode.PKCS7;
        default:
          throw new ArgumentException("paddingMode is a not a supported padding mode", "paddingMode");
      }
    }

    static void PrintByteArray(Byte[] arr) {
      int i;
      Console.WriteLine("Length: " + arr.Length);
      for (i=0; i<arr.Length; ++i) {
        Console.Write("{0:X}", arr[i]);
        Console.Write("    ");
        if ( (i+9)%8 == 0 ) Console.WriteLine();
      }
      if (i%8 != 0) Console.WriteLine();
    }
	}
}
